$(document).ready(function () {
    let modal_status = 0;

    // Hide Alert
    setTimeout(function () {
        $(".piofx_alert").remove();
    }, 5000);

    // Call Blog Api to get popular post
    let url = window.location.origin;
    fetch(url + "/latestPost")
        .then((resp) => resp.json())
        .then((data) => {
            title = data.title;
            slug = data.slug;
            postUrl = url + "/" + slug;

            // Set title and url to show the blog post
            document.getElementById("latestPostTitle").innerHTML = title;
            document
                .getElementById("latestPostUrl")
                .setAttribute("href", postUrl);
        })
        .catch((err) => {
            console.log("Error in fetching popular post" + err);
        });

    // Modal Functionality
    let show_piofx_modal = sessionStorage.getItem("show_piofx_modal");
    if (show_piofx_modal == null) {
        if ($(".piofx_modal").data("position")) {
            $(window).scroll(function () {
                if (!modal_status) {
                    if (
                        $(window).scrollTop() >
                        $(".piofx_modal").data("position")
                    ) {
                        $(".piofx_modal").modal("show");
                        modal_status = 1;
                    } else {
                        $(".piofx_modal").remove();
                    }
                }
            });
        } else {
            if (!modal_status) {
                setTimeout(function () {
                    $(".piofx_modal").modal("show");
                    modal_status = 1;
                }, $(".piofx_modal").data("time"));
            }
        }
    }

    // Toast Functionality
    let toast_status = 0;
    let show_piofx_toast = sessionStorage.getItem("show_piofx_toast");
    if (show_piofx_toast == null) {
        if ($(".piofx_toast").data("position")) {
            console.log("here");
            $(window).scroll(function () {
                if (!toast_status) {
                    if (
                        $(window).scrollTop() >
                        $(".piofx_toast").data("position")
                    ) {
                        $(".piofx_toast").toast("show");
                        toast_status = 1;
                    } else {
                        $(".piofx_toast").remove();
                    }
                }
            });
        } else {
            if (!toast_status) {
                setTimeout(function () {
                    $(".piofx_toast").toast({ autohide: false });
                    $(".piofx_toast").toast("show");
                    toast_status = 1;
                }, $(".piofx_toast").data("time"));
            }
        }
    }

    // Hide or show header text
    let header_text_status = 0;
    $(window).scroll(function () {
        if (header_text_status == 0) {
            if ($(window).scrollTop() >= 500) {
                header_text_status = 1;
                $(".header_text").slideUp();
            }
        } else if ($(window).scrollTop() < 500) {
            header_text_status = 0;
            $(".header_text").slideDown();
        }
    });
});
// End of document ready

var ripple_interval;

setTimeout(function () {
    $(".chat_bubble").css("background", "#425b76");
    $(".chat_bubble").animate(
        {
            width: "4rem",
            height: "4rem",
            "font-size": "1.5rem",
            opacity: "1",
            padding: "1rem",
        },
        { duration: 300 }
    );
    $(".chat_bubble_outer").animate(
        {
            width: "4rem",
            height: "4rem",
            "font-size": "1.5rem",
            opacity: "1",
        },
        { duration: 300 }
    );
    $(".chat_bubble_outer").animate(
        {
            width: "5rem",
            bottom: "0.5rem",
            right: "0.5rem",
            height: "5rem",
            opacity: "0",
        },
        { duration: 800 }
    );
    ripple_interval = setInterval(ripple, 500);
}, 3000);

function ripple() {
    $(".chat_bubble_outer").animate(
        {
            width: "4rem",
            height: "4rem",
            "font-size": "1.5rem",
            bottom: "1rem",
            right: "1rem",
            opacity: "1",
        },
        { duration: 0 }
    );
    $(".chat_bubble_outer").animate(
        {
            width: "5rem",
            bottom: "0.5rem",
            right: "0.5rem",
            height: "5rem",
            opacity: "0",
        },
        { duration: 800 }
    );
}

// Hide Chat Message
function hide_message() {
    $(".chat_message").css("opacity", "0");
}

// Chat Box Functionality
function show_box() {
    clearInterval(ripple_interval);
    // get the device width and add or remove class for full screen view of chat box
    // default class
    let cssClass = "chat_box";
    let screenWidth = window.innerWidth > 0 ? window.innerWidth : screen.width;
    // if device is mobile or tab then use mobile css class
    if (screenWidth < 768) {
        cssClass = "chat_box_mobile";
        $("#chatBoxHead").toggleClass("rounded-top");
    }
    $("#chatBox").toggleClass(cssClass);
    $(".open_chat_bubble").toggle();
    $(".close_chat_bubble").toggle();
}

// Close Toast
function close_toast() {
    toast_status = 1;
    console.log("here");
    $(".piofx_toast").remove();
    sessionStorage.setItem("show_piofx_toast", "false");
}

// Hide Alert
function hide_alert() {
    $(".piofx_alert").remove();
}